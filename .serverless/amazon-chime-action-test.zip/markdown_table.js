(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 7);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("source-map-support/register");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(1);

var _stringify2 = _interopRequireDefault(_stringify);

exports.success = success;
exports.failure = failure;

__webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function success(body) {
  return buildResponse(200, body);
}

function failure(body) {
  return buildResponse(500, body);
}

function buildResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    body: (0, _stringify2.default)(body)
  };
}

/***/ }),
/* 5 */,
/* 6 */,
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _regenerator = __webpack_require__(2);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _keys = __webpack_require__(8);

var _keys2 = _interopRequireDefault(_keys);

var _stringify = __webpack_require__(1);

var _stringify2 = _interopRequireDefault(_stringify);

var _promise = __webpack_require__(9);

var _promise2 = _interopRequireDefault(_promise);

var _asyncToGenerator2 = __webpack_require__(3);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

__webpack_require__(0);

var _lodash = __webpack_require__(10);

var _responseLib = __webpack_require__(4);

var _helpers = __webpack_require__(11);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.main = function () {
  var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(event) {
    var webhook_post, body, j2md, webhook, hostname, details, fields, max_payload, array, fields_out, columns, out, data_len, k, row, temp, temp_check, temp_check_bytes, tableMdString, q, r, s;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            webhook_post = function webhook_post(webhook, data) {
              return new _promise2.default(function (resolve, reject) {
                var request = __webpack_require__(12);

                var options = {
                  url: webhook,
                  body: (0, _stringify2.default)({ 'Content': '/md ' + data }),
                  headers: {}
                };

                request.post(options, function optionalCallback(err, httpResponse, body) {
                  if (err) {
                    console.log(err);
                    reject(err);
                  }
                  resolve(body);
                });
              });
            };

            body = JSON.parse(event.body);
            j2md = __webpack_require__(13);
            webhook = body && body.data && body.form_params.webhook_override ? body.form_params.webhook_override : body.data.webhook;
            hostname = body.scheduled_plan.url.split('/').slice(0, 3).join('/');
            details = body.attachment && body.attachment.data ? JSON.parse(body.attachment.data) : null;
            fields = details && details.fields ? details.fields : {};
            max_payload = 4096;
            array = ['dimensions', 'measures', 'table_calculations'];
            fields_out = [];

            array.forEach(function (item, index) {
              if (fields[item] && fields[item].length > 0) {
                for (var i = 0; i < fields[item].length; i++) {
                  var tmp = fields[item][i];
                  tmp['_type'] = item;
                  tmp['_hidden'] = body.scheduled_plan.query && body.scheduled_plan.query.vis_config && body.scheduled_plan.query.vis_config.hidden_fields && body.scheduled_plan.query.vis_config.hidden_fields.indexOf(tmp.name) > -1;
                  fields_out.push(tmp);
                }
              }
            });

            columns = [];
            out = [];
            data_len = details.data.length;

            // loop through each row of data

            k = 0;

          case 15:
            if (!(k < data_len)) {
              _context.next = 29;
              break;
            }

            row = details.data[k];
            temp = {};

            // loop through each key in JSON

            (0, _keys2.default)(row).map(function (key) {

              // lookup the key in the fields collection
              var find_key = (0, _lodash.find)(fields_out, { 'name': key });

              if (!find_key._hidden) {
                // find the label (short) of the field
                var label = find_key ? find_key.label_short || find_key.label : find_key.name;

                // find the rendered value
                var value = row[key].rendered || row[key].value;

                // if links are on, and the row has links, start the link generation
                if (['all', 'first'].indexOf(body.form_params.include_links) > -1 && row[key] && row[key].links) {

                  // remove actions drills
                  var tmp_links = (0, _lodash.filter)(row[key].links, function (o) {
                    return o.type != 'action';
                  });

                  for (var j = 0; j < tmp_links.length; j++) {
                    if (j == 0) {
                      value = '[' + value + '](' + (0, _helpers.linkURL)(hostname, tmp_links[j].url) + ')';
                    } else if (body.form_params.include_links == 'all') {
                      value = value + ' [[' + tmp_links[j].label + ']](' + (0, _helpers.linkURL)(hostname, tmp_links[j].url) + ')';
                    }
                  }
                }
                columns.push(label);
                temp[label] = value;
              }
            });

            temp_check = out.concat([temp]);
            temp_check_bytes = ('/md ' + j2md(temp_check, (0, _lodash.uniqBy)(columns))).length;

            if (!(temp_check_bytes <= max_payload)) {
              _context.next = 25;
              break;
            }

            out.push(temp);
            _context.next = 26;
            break;

          case 25:
            return _context.abrupt('break', 29);

          case 26:
            k++;
            _context.next = 15;
            break;

          case 29:

            out = (0, _lodash.compact)(out);

            tableMdString = j2md(out, (0, _lodash.uniqBy)(columns));

            if (false) {}

            if (!(body.form_params.send_title == 'yes')) {
              _context.next = 36;
              break;
            }

            _context.next = 35;
            return webhook_post(webhook, body.scheduled_plan.title);

          case 35:
            q = _context.sent;

          case 36:
            _context.next = 38;
            return webhook_post(webhook, tableMdString);

          case 38:
            r = _context.sent;

            if (!(k < data_len)) {
              _context.next = 43;
              break;
            }

            _context.next = 42;
            return webhook_post(webhook, 'Showing ' + k + '/' + data_len.toLocaleString('en-US') + ' rows. [See all rows](' + body.scheduled_plan.url + ')');

          case 42:
            s = _context.sent;

          case 43:
            if (!(r && r.MessageId && r.RoomId)) {
              _context.next = 47;
              break;
            }

            return _context.abrupt('return', (0, _responseLib.success)(r));

          case 47:
            return _context.abrupt('return', (0, _responseLib.failure)(r));

          case 48:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, undefined);
  }));

  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/object/keys");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.linkURL = linkURL;

__webpack_require__(0);

function linkURL(hostname, link) {
  return hostname + link.replace(' ', '+');
}

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("request");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("json-to-markdown");

/***/ })
/******/ ])));
//# sourceMappingURL=markdown_table.js.map